# Write a program the amostrong Number between 1 to 500.

# for num in range(500):
#     # Find the number of digits in the current number
#     num_str = str(num)
#     num_digits = len(num_str)
    
#     # Calculate the sum of the cubes of each digit in the number
#     digit_sum = 0
#     for digit in num_str:
#         digit_sum += int(digit) ** num_digits
    
#     # Check if the sum of the cubes is equal to the original number
#     if digit_sum == num:
#         print(num)

lower = int(input("Enter lower range: "))  
upper = int(input("Enter upper range: "))  
  
for num in range(lower,upper + 1):  
   sum = 0  
   temp = num  
   while temp > 0:  
       digit = temp % 10  
       sum += digit ** 3  
       temp //= 10  
       if num == sum:  
            print(num) 