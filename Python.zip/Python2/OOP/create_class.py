class person:
    def __int__(self, a='Alok', b='Male'):
        self.name=a
        self.gender=b
    def showinfo(self):
        print('Name:', self.name)
        print('Gender:', self.gender)