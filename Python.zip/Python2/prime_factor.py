## All steps 
# 1. Accept Input from user(n)      =>    num = int(input("enter a number: ")) 
# 2. Set divisor (|f) to 2          =>    d = 2
# 3. perfome setp 4 and 5 til n>1   =>    while num>1
# 4. chache if given number(n)
#    id divisiable by divisor (d)    

# 5. if n%d==0                      => if num%d==0
# 6. print d as a factor            => print(d)
# 7. set new value of n as n/d      => num = num/d 
# 8. Repeat from 4                  => continue
# 9. else
# 10. incriment d by 1              =>  d= d+1
# 11. Repeat fro, 3



num = int(input("Enter a number: "))
d=2
while num>1:
    if num%d==0:
        print(d)
        num = num/d
        continue
    d=d+1