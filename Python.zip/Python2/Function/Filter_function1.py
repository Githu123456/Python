"""
The filter() function returns an iterator where the items are fitered through a
function to test if the item is accepted or not
"""

# ages = [12,15,18,22,24,30,26]
# def myfunction(x):
#     if x < 20:
#         return False
#     else:
#         return True
# adult = list(filter(myfunction ,ages))

# for x in adult:
#     print(x)



## for Lamda funnction
ages = [12,15,18,22,24,30,26]
adult = filter(lambda a : a > 20, ages)
for x in adult:
    print(x)