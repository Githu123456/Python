# NO ARGUMENT WITH RETURN

def addition():
    i = int(input("Enter 1st Number: "))
    x = int(input("Enter 2nd Number: "))
    y = i + x
    return y 

a = addition()
print("Addition is: ", a)