# WITH ARGUMENT NO RETURN

def addition():
    y = i + x
    print("Addiion is: ", y)

i = int(input("Enter 1st Number: "))
x = int(input("Enter 2nd Number: "))
addition(i , x)