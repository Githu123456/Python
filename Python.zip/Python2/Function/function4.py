# WITH ARGMENT WITH RETUEN

def addition(i , x):
    y = i + x
    print("Addiion is: ", y)

i = int(input("Enter 1st Number: "))
x = int(input("Enter 2nd Number: "))
A = addition(i , x)
print("Addition is: ", A)