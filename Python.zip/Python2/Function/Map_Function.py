"""
The map() function executes a specified function for each iteam in a iterable.
The iteam is sent to the function as perameter
"""
ages = [12,45,25,18,74,56,12,45,25,26,23]
def myfunction(x):
    if x < 20:
        return False
    else:
        return True
def myfunc(x):
    return x*x
adult = list(filter(myfunction, ages))
for x in adult:
    print(x)
squere = list(map(myfunc,adult))
for x in squere:
    print(x)


## Doing the same with Lamda function

# ages = [12,45,25,18,74,56,12,45,25,26,23]
# adult = filter(lambda a: a > 20, ages)
# squere = list(map(lambda a: a*a, adult))
# print(squere)