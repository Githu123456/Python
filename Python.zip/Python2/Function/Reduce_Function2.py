# Finding Max number in the list usng Reduce() function.

# from functools import reduce
# val = [25,42,78,12,45,74,63,2,48]

# def myfunc(a,b):
#     if a > b:
#         return a
#     else:
#         return b
# max = reduce(myfunc,val)
# print("Max number is = ",max)


# Finding Max number in the list usng Reduce() function and Lamda function.

from functools import reduce
val = [25,42,78,12,45,74,63,2,48]
max = reduce(lambda a,b:a if a > b else b, val)
print("Max number is = ",max)