# all even num,bers will be sen,d
# val = [12,45,7,25,16,45,78,95,68,23,82]
# def myfunc(a):
#     if a%2==0:
#         return True
#     else:
#         return False
# even = list(filter(myfunc, val))
# for a in even:
#     print(a)


## With Lamda

val = [12,45,7,25,16,45,78,95,68,23,82]
even = filter(lambda a : a%2==0, val)
for a in even:
    print(a)