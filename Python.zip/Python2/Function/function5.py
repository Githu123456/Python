## Function Details
# Pi wants anything between 7000 and 10000 rupees! So help Pi write a function that will check whether the amount his sister offers to give him (variable, sis) is within the required range of rupees.
# If the number less than 7000, show the message, "Ahem, can you rethink this number please?".
# If the number is greater than 10000, show the message, "Wow sis! You are a queen".
# If the number is within the range, show the message, "Cool, thanks sis! x rupees will certainly help."


def checkmoney(x):
    if x in range(7000, 10000) :
        print("Cool, thanks sis! {} rupees will certainly help.".format(x))
    elif 7000<x:
        print("Ahem, can you rethink this number please?")
    elif x>10000:
        print("Wow sis! You are a queen")

    return

sis=8500
checkmoney(sis)