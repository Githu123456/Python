"""
The reduce(fun,seq) function is used to apply a particular function passsed in its argument
to all of the list element mentioned in the sequence passed along. This function is defined
in " functions " module. At first step, first two element of sequence are picked and the 
result is obtained.

# Working

* At first step, first two element of sequence are picked and the result is obtained.
* Next step is to apply the same funtion to the previously attained result and the number
  just succeeding the second element and the result is agin stored.
* This process continues till no more element are lest in the contsiner. The final returend
  result is returend and printed on consle
"""

# Sum of List element using Reduce() funtion

# from functools import reduce
# val = [1,2,3,4,5]
# def myfunc(a,b):
#     return a+b
# add = reduce(myfunc,val)
# print("Addition = ",add)

## Sum of List element using Reduce() funtion and Lamda Function

# from functools import reduce
# val = [1,2,3,4,5]
# add = reduce(lambda a,b:a+b, val)
# print("Addition = ",add)


add_numbers = (lambda x, y: x + y)
add_number = (lambda x, y: x - y)

result = add_numbers(3, 5)
resul = add_number(3, 5)
print(result)  # Output: 8
print(resul)