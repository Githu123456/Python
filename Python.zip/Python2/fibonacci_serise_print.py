# WRITE A PROGRAME TO PRINT FIBONACCI SERISE UPTO GIVEN NUMBER.

n = int(input("Enter number: "))
x = 0
y = 1
z = 0
while (z<=n):
    print(z)
    x = y
    y = z
    z = x + y



# '''
# THER ALREDY GIVEN TWO NUMBE THAT IS 0 AND 1. THEN IT WILL SUM WITH GIVEN TWO NUMBER 
# AFTER THAT THE LAST NUMBER OF GIVEN TWO NUMBER AND SUM OF GIVEN TWO NUMBER WILL BE SUM.
# AND IT WILL BE CONTINUE AT LIMIT GIVEN BY US.
# EXAMPLE
# OUR MAX LIMIT OF NUMBER IS 15.
# SO
# WE HAVE ALREADY TWO NUMBE THAT IS 0 AND 1
# SO 
# (0+1=1)
# (1+1=2)
# (1+2=3)
# (2+3=5)
# (3+5=8)
# (5+8=13)
# AWS=
# 0
# 1
# 1
# 2
# 3
# 5
# 8
# 13
# '''