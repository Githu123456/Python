# WRITE A PROGRAME TO CHACK WHETHER A GIVEN NUMBER IS PRIME OR NOT ?

n = int(input("Enter the number : "))
count = 0
i = 1
while(i<=n):
    if(n%i==0):
        count = count + 1
    i = i+1
if (count == 2):
    print("This is the prime Number")
else:
    print("This is not the prime number")



'''
IF WE TAKE A NUMBER WHICH IS DEVIDE BY 2 FACTOR 
EXAMPLE:
IF WE TAKE NUMBER 13. THEN IF WE DEVIDE THE NUMBER 13 WE WILL GET 1 OR 13 WHICH IS DEVIDE THE NUMBER 13
SO HERE 1 IS FACTOR AND 13 IS FACTOR
SO ANY KIND OF NUMBER WHICH IS DEVIDE ONLY 2 FACRTOR. MORE THAN THAT
THAT IS CALL PRIME NUMBER
'''