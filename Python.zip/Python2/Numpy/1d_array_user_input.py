import numpy as np
a = []
n = int(input("Enter the size; "))
for i in range(n):
    val = (input("Enter number: "))
    a.append(val)
myarry = np.array(a)
print(myarry)
