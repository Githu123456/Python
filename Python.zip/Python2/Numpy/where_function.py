"""
We can search a value in an array and is the vlue is found the concerned index is returend. 
To search an array. we use where() method.
"""

import numpy as np
arr = np.array([10,20,30,40,50,60,40,50,40,60,30,40,70])
a = np.where(arr==40)
print(a)