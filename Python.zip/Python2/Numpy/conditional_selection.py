import numpy as np
arr = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
b = arr>10
# print(b)
print(arr[b])

# Output: [11,12,13,14,15]


arr = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
b = arr<10
# print(b)
print(arr[b])

# Output: [1,2,3,4]


arr = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
b = arr%2==0
# print(b)
print(arr[b])

# Output: [2,4,6,8,10,12,14]



arr = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
b = arr[arr%2==0]=0
# print(b)
print(arr[b])

# Output: [1,0,3,0,5,0,7,0,9,0,11,0,13,0,15]



arr = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
b = arr==10
# print(b)
print(arr[b])

# Output: [10]


arr = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
b = arr>10
# print(b)
print(arr[b])

# Output: [11,12,13,14,15]