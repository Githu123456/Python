# View is updating orginal Data 
# and 
# Copy is not updating original data just copy and show it 
# both ar working in slicing



###   View
# view is allways is defualt

import numpy as np
a = np.array([10, 20, 30, 40, 50, 60, 70, 80, 90])
slicing = a[3:6]
slice[:] = 0
print(a)





### Copy

import numpy as np
a = np.array([10, 20, 30, 40, 50, 60, 70, 80, 90])
slicing = a[3:6].copy
slice[:] = 0
print(a)
print(slice)