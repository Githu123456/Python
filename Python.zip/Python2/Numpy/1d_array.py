# import numpy as np
# a = [1, 2, 3, 4, 5]
# myarray = np.array(a)
# print(myarray)

# or

import numpy as np
myarry = np.array([1, 2, 3, 4, 5])
print(myarry)