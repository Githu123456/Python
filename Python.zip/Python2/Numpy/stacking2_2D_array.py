import numpy as np
arr1 = np.random.randint(1,21,9).reshape(3,3)
arr2 = np.random.randint(31,51,9).reshape(3,3)
a = np.hstack((arr1, arr2)) # Horizontally Arranges the matrix
b = np.vstack((arr1,arr2))# Vartically Arranges the matrix
print(arr1)
print(arr2)
print(a)
print(b)
