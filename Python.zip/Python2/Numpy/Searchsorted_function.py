"""
This method performed a Binary search in the array. and returns the index
where the specified value whould be inserted to minimum the search order.

"""
import numpy as np
arr = np.array([2,5,7,9,10])
a = np.searchsorted(arr,6)
print(arr)
print(a)