# import numpy as np
# a = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
# myarray = np.array(a)
# print(myarray)

# or

import numpy as np
myarry = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print("Total Dimanssion=", myarry.ndim)
print("Shape of array =", myarry.shape)