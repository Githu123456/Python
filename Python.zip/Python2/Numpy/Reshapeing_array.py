# RESHAPEING 1D ARRAY TO 2D ARRAY

import numpy as np
arr = np.random.randint(1,100,12)
print(arr)
# will print 12 numberws
arr.shape
# will print (12,)
# convarting it to 2d array
arr = arr.reshape(3,4)
# or 
# arr = arr.reshape(2,6)
# or
# arr = arr.reshape(4,3)

# Because 2*6=12, 3*4=12, 4*3=12 it will work for
# any conbination which is 12 otherwise it will show anm error

print(arr)
print("After reshaping =", arr.ndim)

# Convarting agin this 2D array to 1D array

arr = arr.reshape(12)
print(arr)
print("After reshaping =", arr.ndim)

# Convarting to 3D array

arr = arr.reshape(2,2,3)
print(arr)
print("After reshaping =", arr.ndim)

