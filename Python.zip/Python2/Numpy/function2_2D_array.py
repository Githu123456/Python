import numpy as np
np.random.seed(102)
matrix = np.random.randint(1,21,9).reshape(3,3)
a = np.sum(matrix) # Find the sum of array
# or
# a = matrix .sum()
b = np.min(matrix) # Find the min number of matrix
c = np.max(matrix) # Find the max number of matrix
d = np.min(matrix, axis=1) # Find row wise min
e = np.max(matrix, axis=0) # Find colume wise max value
# Remember  always that when Row wise the axis=1 and Colume wise axis=0 
f = np.sum(matrix, axis=1) # Finds row wise sum
g = np.sum(matrix, axis=0) # Finds colume wise sum
h = np.cumsum(matrix) # Cumulative sum
i = np.cumsum(matrix, axis=1) # Row wise Cumulative sum
j = np.cumsum(matrix, axis=0) # Colume wise Cumulative sum

print(matrix)
print(a)
print(b)
print(c)
print(d)
print(e)
print(f)
print(g)
print(h)
print(i)
print(j)