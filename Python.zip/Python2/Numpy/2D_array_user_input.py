import numpy as np

# 1st create a 2D array

matrix = []
row = int(input("Enter Number of Row: "))
col = int(input("Enter Number of Col: "))
for i in range(row):
    a = []
    for i in range(col):
        val = int(input("Enter Number: "))
        a.append(val)
    matrix.append(a)

# convert into Array

arr = np.array(matrix)

for i in range(row):
    for j in range(col):
        print(arr[i][j],end=" ")
    print()
print(type(arr))