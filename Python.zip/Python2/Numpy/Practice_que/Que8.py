# Concatenate 2D array horizontally and vertically.
import numpy as np
arr1 = np.arange(1,10).reshape(3,3)
arr2 = np.arange(10,19).reshape(3,3)
a = np.hstack((arr1,arr2))
b = np.vstack((arr1,arr2))
print(arr1)
print(arr2)
print(a)
print(b)
