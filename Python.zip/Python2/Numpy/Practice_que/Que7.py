# Perfrom the slicing input(1 to 16) and out(6 to 15)
import numpy as np
arr = np.arange(1,17).reshape(4,4)
a = arr[1:4,1:3]
print(arr)
print(a)