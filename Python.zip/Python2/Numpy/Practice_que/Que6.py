# Create a 2D array of size 3*3 but all the elements should be between 0 and 1
import numpy as np
np.random.seed(102)
arr = np.random.rand(9).reshape(3,3)
print(arr)