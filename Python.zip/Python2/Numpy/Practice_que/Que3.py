# Create an array which contins value 5, 10 times.
import numpy as np
arr = np.ones(10)*5
print(arr)