# Create an array of 10 random integers ?
import numpy as np
arr = np.random.randint(1,50,10)
print(arr)