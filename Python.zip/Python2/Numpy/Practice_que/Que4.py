# Create a no dimantionaql array and conver into a 2D array.
import numpy as np
arr = np.arange(1,10)
a = arr.reshape(3,3)
print(arr)
print(a)
