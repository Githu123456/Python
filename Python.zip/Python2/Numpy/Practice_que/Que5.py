# Create an array and then conver all the even numbers with 0.
import numpy as np
arr = np.arange(1,10)
arr[arr%2==0]=0
print(arr)
