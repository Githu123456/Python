# Create an array of element from 10-20 ?
import numpy as np
arr = np.arange(10,21)
print(arr)