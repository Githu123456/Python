# Slicing/ Indexing of two dimantional array may be done by
# two ways:
# 1.Indexing/Slicing using double bracket notation. a[0][0]
# 2.Indexing/Slicing using single bracket notation. a[0,0]

# syntax: a[Row range, col range]

import numpy as np

np.random.seed(111)
a = np.random.randint(1,500,30).reshape(6,5)
print(a)

b = a[1:5,2:4]
print(b)