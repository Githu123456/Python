import numpy as np
np.random.seed(102)
arr = np.random.randint(1,21,10)
a = np.random.shuffle(arr) # Shaffles the array elements
b = np.unique(arr) # Display unique number of the array
c = np.unique(arr).size # Counts the unique count of element
d = np.unique(arr,return_index=True,return_counts=True)
"""
It is returns three array
1. The array with unique values
2. The array with respective index values
3. The array with counting of frequency
"""
print(arr)
print(a)
print(b)
print(c)
print(d)
