"""
Stacking is 2 type-
1. Vertical stacking
2. Horzontal stacking

"""

import numpy as np
arr1 = np.array([1,2,3,4])
arr2 = np.array([5,6,7,8])
a = np.hstack((arr1, arr2)) # Horizontally Arranges the matrix
b = np.vstack((arr1,arr2))# Vartically Arranges the matrix
print(arr1)
print(arr2)
print(a)
print(b)
