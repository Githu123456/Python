import numpy as np
arr = np.array([10,20,30,40,50])
a = np.min(arr) # Returns the min number
b = np.max(arr) # Return the max number
c = np.argmin(arr) # Position of min number
d = np.argmax(arr) # Position of max number
e = np.sqrt(arr) # Squar root of every number
f = np.sin(arr) # Sin value of every number 
g = np.cos(arr) # Cos value of every number

print(a)
print(b)
print(c)
print(d)
print(e)
print(f)
print(g)

"""
# Linspace

Linspace function returns values between a given 
range and with  a some gap between consective elements.
"""

h = np.linspace(10,50,13)
print(h)