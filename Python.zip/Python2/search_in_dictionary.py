# WRITE A PROGRAME TO STORE STUDENTS INFORMATIONS LIKE ADMISSION NUMBER, ROLL NUMBER, NAME AND MARKES 
# IN A DICTIONARY AND DISPLAY INFORMATION ON THE BASISI ON THE ADMISSION NUMBER .

student_DB = {}

# ask input from user or 'q' to exit
while True:
    line = input("please input the ID and name separated by comma or q to exit: ")
    if line == 'q':
        break
    id, name = line.split(',')
    student_DB.update({id:name})

# output
for x,y in student_DB.items():
    print(x,y)

# searching a key
key = input("Enter ID to search: ")
if key in student_DB:
    print("key=","key", "value=", student_DB[key])
else:
    print("key nopt found")