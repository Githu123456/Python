class Book:
    def __init__(self, title, author, publisher, price):
        self.title = title
        self.author = author
        self.publisher = publisher
        self.price = price
        self.author_royalty = 0

    @property
    def title(self):
        return self._title
    
    @title.setter
    def title(self, value):
        self._title = value

    @property
    def author(self):
        return self._author
    
    @author.setter
    def author(self, value):
        self._author = value

    @property
    def publisher(self):
        return self._publisher
    
    @publisher.setter
    def publisher(self, value):
        self._publisher = value

    @property
    def price(self):
        return self._price
    
    @price.setter
    def price(self, value):
        self._price = value

    def royalty(self, copies_sold):
        if copies_sold <= 500:
            self.author_royalty = self.price * 0.10 * copies_sold
        elif copies_sold <= 1500:
            self.author_royalty = (500 * 0.10 + (copies_sold - 500) * 0.125) * self.price
        else:
            self.author_royalty = (500 * 0.10 + 1000 * 0.125 + (copies_sold - 1500) * 0.15) * self.price

class Ebook(Book):
    def __init__(self, title, author, publisher, price, ebook_format):
        super().__init__(title, author, publisher, price)
        self.ebook_format = ebook_format

    @property
    def ebook_format(self):
        return self._ebook_format
    
    @ebook_format.setter
    def ebook_format(self, value):
        self._ebook_format = value

    def royalty(self, copies_sold):
       
        super().royalty(copies_sold)

        
        gst_deduction = 0.12 * self.author_royalty
        self.author_royalty -= gst_deduction

# Example usage:
physical_book = Book("Sample Book", "John Doe", "ABC Publishers", 20.0)
physical_book.royalty(1000)
print(f"Physical Book Royalty: ${physical_book.author_royalty:.2f}")

ebook = Ebook("Sample eBook", "John Doe", "XYZ Publishers", 15.0, "PDF")
ebook.royalty(800)
print(f"Ebook Royalty: ${ebook.author_royalty:.2f}")
