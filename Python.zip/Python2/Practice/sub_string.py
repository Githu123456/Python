#Given a string A and two integer B and C.

#Find and return the substring of A starting from index 
#B and ending with index C.


def get_substring(A, B, C):
    if B < 0 or C >= len(A) or B > C:
        return "Invalid indices"  # Check for invalid indices
    
    substring = A[B : C + 1]  # Extract the substring using slicing
    return substring
string_A = "Hello, World!"
index_B = 2
index_C = 8
result = get_substring(string_A, index_B, index_C)
print(result)