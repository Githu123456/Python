import tkinter as tk

class FantasyCricketApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Fantasy Cricket App")
        self.team_name = ""
        self.selected_players = []

        # Create the menu
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Team", command=self.create_team)

        self.player_listbox = tk.Listbox(self.root)
        self.player_listbox.pack(side=tk.LEFT)

        self.team_listbox = tk.Listbox(self.root)
        self.team_listbox.pack(side=tk.RIGHT)

        self.update_player_list()

    def update_player_list(self):
        # Fetch and display the list of available players based on category
        # You would fetch this data from your data source
        players = ["Player 1", "Player 2", "Player 3", "Player 4"]
        self.player_listbox.delete(0, tk.END)
        for player in players:
            self.player_listbox.insert(tk.END, player)

    def create_team(self):
        team_name = tk.simpledialog.askstring("Team Name", "Enter your team name:")
        if team_name:
            self.team_name = team_name
            self.selected_players = []  # Clear any existing players
            self.team_listbox.delete(0, tk.END)
            self.update_player_list()

    def add_player(self, player_name):
        if len(self.selected_players) < 11:
            self.selected_players.append(player_name)
            self.team_listbox.insert(tk.END, player_name)
        else:
            tk.messagebox.showinfo("Error", "You can't select more than 11 players.")

if __name__ == "__main__":
    root = tk.Tk()
    app = FantasyCricketApp(root)
    root.mainloop()
