CREATE TABLE books (
    book_id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    author TEXT,
    price REAL
);

INSERT INTO books (title, author, price) VALUES
    ('Book 1', 'Author 1', 10.99),
    ('Book 2', 'Author 2', 15.99),
    ('Book 3', 'Author 3', 12.49);