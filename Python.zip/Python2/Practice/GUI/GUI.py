import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.uic import loadUi
import sqlite3

class BookApp(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("my.ui", self)  

        self.find_price_button.clicked.connect(self.find_price)
        self.find_total_button.clicked.connect(self.find_total_amount)

        # Connect to the SQLite database
        self.conn = sqlite3.connect("database.db")  
        self.cursor = self.conn.cursor()

    def find_price(self):
        title = self.title_input.text()
        query = "SELECT price FROM books WHERE title = ?"
        self.cursor.execute(query, (title,))
        result = self.cursor.fetchone()
        if result:
            self.price_input.setText(str(result[0]))
        else:
            self.show_message("Book not found")

    def find_total_amount(self):
        title = self.title_input.text()
        quantity = self.quantity_input.value()
        query = "SELECT price FROM books WHERE title = ?"
        self.cursor.execute(query, (title,))
        result = self.cursor.fetchone()
        if result:
            price = result[0]
            total_amount = price * quantity
            self.price_input.setText(str(price))
            self.total_input.setText(str(total_amount))
        else:
            self.show_message("Book not found")

    def show_message(self, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(message)
        msg.setWindowTitle("Warning")
        msg.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BookApp()
    window.show()
    sys.exit(app.exec_())
