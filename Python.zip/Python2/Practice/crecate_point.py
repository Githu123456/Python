#### Module: cricket_points_module.py

def calculate_batting_points(runs, balls_faced, boundaries, sixes):
    points = runs // 2
    if runs >= 50:
        points += 5
    if runs >= 100:
        points += 10
    strike_rate = (runs / balls_faced) * 100
    if 80 <= strike_rate <= 100:
        points += 2
    elif strike_rate > 100:
        points += 4
    points += boundaries + (2 * sixes)
    return points

def calculate_bowling_points(wickets, economy_rate):
    points = wickets * 10
    if wickets >= 3:
        points += 5
    if wickets >= 5:
        points += 10
    if 3.5 <= economy_rate <= 4.5:
        points += 4
    elif 2 <= economy_rate < 3.5:
        points += 7
    elif economy_rate < 2:
        points += 10
    return points



### Main Script: main.py

from cricket_points_module import calculate_batting_points, calculate_bowling_points

players_data = [
    {'name': 'Virat Kohli', 'runs': 83, 'balls_faced': 60, 'boundaries': 8, 'sixes': 2,
     'wickets': 0, 'overs_bowled': 0, 'runs_given': 0},
    {'name': 'du Plessis', 'runs': 94, 'balls_faced': 70, 'boundaries': 10, 'sixes': 0,
     'wickets': 0, 'overs_bowled': 0, 'runs_given': 0},
    {'name': 'Bhuvneshwar Kumar', 'runs': 0, 'balls_faced': 0, 'boundaries': 0, 'sixes': 0,
     'wickets': 1, 'overs_bowled': 10, 'runs_given': 40},
    {'name': 'Yuzvendra Chahal', 'runs': 0, 'balls_faced': 0, 'boundaries': 0, 'sixes': 0,
     'wickets': 4, 'overs_bowled': 10, 'runs_given': 24},
    {'name': 'Kuldeep Yadav', 'runs': 0, 'balls_faced': 0, 'boundaries': 0, 'sixes': 0,
     'wickets': 2, 'overs_bowled': 10, 'runs_given': 42}
]

for player in players_data:
    batscore = calculate_batting_points(player['runs'], player['balls_faced'], player['boundaries'], player['sixes'])
    bowlscore = calculate_bowling_points(player['wickets'], player['runs_given'] / (player['overs_bowled'] if player['overs_bowled'] > 0 else 1))
    player['batscore'] = batscore
    player['bowlscore'] = bowlscore

top_player = max(players_data, key=lambda x: x.get('batscore', 0) + x.get('bowlscore', 0))
print(top_player)
