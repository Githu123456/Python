## Calculate total cntribution per person

def food(f):
    tip=0.1*f
    f=f+tip
    fperson=f/num
    return fperson
def movie(m):
    return m/num

num = int(input(" No of person: "))
ftotal = int(input("Spend on food : "))
mtotal = int(input("Spent on movie : "))

x=food(ftotal)
y=movie(mtotal)
print("Per person total is ", x+y)