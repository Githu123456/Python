import sqlite3

# Connect to or create a SQLite database
conn = sqlite3.connect("bookstore.db")
cursor = conn.cursor()

# Create a books table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS books (
        book_id INTEGER PRIMARY KEY,
        title TEXT NOT NULL,
        author TEXT,
        price REAL
    )
""")

# Insert data into the books table
cursor.execute("INSERT INTO books (title, author, price) VALUES (?, ?, ?)", ("Think Python", "Allen B. Downey", 475.0))

# Commit changes and close the connection
conn.commit()
conn.close()
