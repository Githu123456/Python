import sqlite3

# Connect to the existing SQLite database
conn = sqlite3.connect("bookstore.db")
cursor = conn.cursor()

# Function to fetch the price of a book by title
def get_book_price(title):
    cursor.execute("SELECT price FROM books WHERE title=?", (title,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        return None

# Input from the user
book_title = input("Enter the title of the book: ")
quantity = int(input("Enter the number of copies: "))

# Fetch the price from the database
price = get_book_price(book_title)

if price is not None:
    # Calculate the total amount
    total_amount = price * quantity
    print(f"Total amount for {quantity} copy/copies of '{book_title}': Rs. {total_amount}")
else:
    print(f"Book with title '{book_title}' not found in the database.")

# Close the database connection
conn.close()
