from Cricket_point_count import batting_point, bowling_point, fielding_point

players_data = [
    {'name': 'Virat Kohli', 'runs': 83, 'balls_faced': 60, 'boundaries': 8, 'sixes': 2,
     'wickets': 0, 'overs_bowled': 0, 'runs_given': 0, 'catch': 1, 'stumping': 2, 'run_out': 0},
    {'name': 'du Plessis', 'runs': 94, 'balls_faced': 70, 'boundaries': 10, 'sixes': 0,
     'wickets': 0, 'overs_bowled': 0, 'runs_given': 0, 'catch': 1, 'stumping': 0, 'run_out': 1},
    {'name': 'Bhuvneshwar Kumar', 'runs': 0, 'balls_faced': 0, 'boundaries': 0, 'sixes': 0,
     'wickets': 1, 'overs_bowled': 10, 'runs_given': 40, 'catch': 0, 'stumping': 0, 'run_out': 0},
    {'name': 'Yuzvendra Chahal', 'runs': 0, 'balls_faced': 0, 'boundaries': 0, 'sixes': 0,
     'wickets': 4, 'overs_bowled': 10, 'runs_given': 24, 'catch': 2, 'stumping': 1, 'run_out': 1},
    {'name': 'Kuldeep Yadav', 'runs': 0, 'balls_faced': 0, 'boundaries': 0, 'sixes': 0,
     'wickets': 2, 'overs_bowled': 10, 'runs_given': 42, 'catch': 0, 'stumping': 1, 'run_out': 0}
]

for player in players_data:
    batscore = batting_point(player['runs'], player['balls_faced'], player['boundaries'], player['sixes'])
    #bowlscore = bowling_point(player['wickets'], player['runs_given'] / (player['overs_bowled'] if player['overs_bowled'] > 0 else 1))
    bowlscore = bowling_point(player['wickets'], player['overs_bowled'], player['runs_given'])
    fielscore = fielding_point(player['catch'], player['stumping'], player['run_out'])
    player['batscore'] = batscore
    player['bowlscore'] = bowlscore
    player['fielscore'] = fielscore

top_player = max(players_data, key=lambda x: x.get('batscore', 0) + x.get('bowlscore', 0)+ x.get('fielscore'))
print(top_player)