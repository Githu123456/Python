def batting_point(runs, ball_faced, boundares, sixes):
    points = runs//2
    if runs >= 50:
        points = points + 5
    if runs >= 100:
        points = points + 10
        
    if runs > 0:
        stricl_rate = (runs/ball_faced)*100
        if 80<= stricl_rate <= 100:
            points = points + 2
        elif stricl_rate > 100:
            points = points + 4
        points = boundares + (2 * sixes)
    return points

def bowling_point(wickets, runs_given, overs_bowled):
    points = wickets * 10
    if wickets >= 3:
        points = points + 5
    if wickets >= 5:
        points = points + 10
    if overs_bowled > 0:
        economy_rate =runs_given/overs_bowled
        if 3.5 <= economy_rate <= 4.5:
            points = points + 4
        elif 2 <= economy_rate <= 2:
            points = points + 7
        elif economy_rate < 2:
            points = points + 10
    return points

def fielding_point(catch, stumping, run_out):
    points = catch * 10
    points = stumping * 10
    points = run_out * 10
    return points