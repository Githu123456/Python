# WRITE A PROGRAME TO FIND SUM OF EVEN DIGITS AND PRODUCTS OF ODD DIGITS OF A GIVEN NUMBER.
val = int(input("Enter the Number : "))
sum = 0
pro = 1
# for i in range(val):
while (val>0):
    a = val%10
    if a%2==0:
        sum = sum + a
    else:
        pro = pro * a
    val = val//10
print("sum of digits =", sum, "product of digitys = ", pro)