# WRITE A PROGRAME TO PRINT FACTORIAL OG GIVEN NUMBER ?

n=int(input("Enter the number : "))
i = 1
while(n>0):
    i = i*n
    n = n-1
print("Factorial is: ", i)


# '''
# EXAMPLE OF A FACTORIAL 
# NUMBER 5 FACTORIAL IS (5*4*3*2*1 = 120)
# SO NUMBER 5 FACTORIAL IS 120
# '''