# WRITE A PROGRAME TO CHEACK WHETHER A NUMBER IS PALINDROME OR NOT ?

n = int(input("Enter number: "))
rev = 0
x = n


while(n>0):
    rev = (rev*10)+n%10
    n = n//10
if (x==rev):
    print("This is the palondron number")
else:
    print("Tyhis is not the palondron number")


'''
PALINDROME NUMBE MEANS THAT IF WE TAKE A NUMBER WHICH WILL WE REVERSE THEN THE NUMBER WILL 
SAME AS TAKEN NUMBER THAT IS CALLED PALINDROME NUMBER 
EXAMPLE 252 OR 525 THEN REVERSE IT.
THEN WE SAW IT WILL SAW LIKE SAME AS TAKEN NUMBER 252 OPR 525 
'''