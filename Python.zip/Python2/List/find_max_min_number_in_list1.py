# WRITE A PROGRAME TO FIND MAX AND MIN NUMBER IN THE LIST

a = []
size = int(input("Enter Size of the List: "))
for i in range(size):
    val = int(input("Enter Number: "))
    a.append(val)
max = a[0]
min = a[0]
for i in range(size):
    if(a[i]>max):
        max = a[i]
        
for i in range(size):
    if(a[i]<min):
       
        min = a[i]
print("Maqx number: ", max , "min number: ", min)