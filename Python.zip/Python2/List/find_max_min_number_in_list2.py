# WRITE A PROGRAME TO FIND MAX AND MIN NUMBER IN THE LIST 
# WITH BUILD IN FUNCTION

a = []
size = int(input("Enter size of the list: "))
for i in range(size):
    val = int(input("Enter number : "))
    a.append(val)
maxval = max(a)
minval = min(a)
print("max number = ", maxval)
print("min number = ", minval)