# WRITE A POGRAME TO FIND 2ND MIN NUMBER ON THE LIST

a = []
size = int(input("Enter size of the list: "))
for i in range(size):
    val = int(input("Enter number : "))
    a.append(val)

minval = min(a)
print("min value in the list is: ", minval)
a.remove(minval)
smin = min(a)
print("second min value us the list is : ", smin)