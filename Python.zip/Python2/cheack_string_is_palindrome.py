# WRITE A POGRAME TO CHACK A STRING IS PALINDROME OR NOT.

a = input("Enter string : ")
b = a[-1::-1]
if(a==b):
    print("It is a Palindron string")
else:
    print("It is not a palindrome string")