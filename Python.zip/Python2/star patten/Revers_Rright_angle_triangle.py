# n = int(input("Enter Limit: "))
# i = 1
# while(i<=n):
#     b = 1
#     while(b<=n-i):
#         print(" ", end="")
#         b = b+1
#     j = 1
#     while(j<=i):
#         print("*", end="")
#         j = j+1
#     print()
#     i = i+1


# n = int(input("Enter Limit: "))
# i = 1
# while(i<=n):
#     b = 1
#     while(b<=n-i):
#         print(" ", end="")
#         b = b+1
#     j = 1
#     while(j<=i):
#         print(j, end="")
#         j = j+1
#     print()
#     i = i+1



n = int(input("Enter Limit: "))
i = 1
while(i<=n):
    b = 1
    while(b<=n-i):
        print(" ", end="")
        b = b+1
    j = 1
    while(j<=i):
        print(i, end="")
        j = j+1
    print()
    i = i+1


##  with for loop

# n = int(input("Enter Limit: "))
# for i in range(n):
#     for b in range(n - i):
#         print(" ", end="")
#     for j in range(i):
#         print(i, end="")
#     print()