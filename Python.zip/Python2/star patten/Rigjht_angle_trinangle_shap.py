# n = int(input("Enter Limit: "))
# i = 1
# while(i<=n):
#     j = 1
#     while(j<=i):
#         print("*", end=" ")
#         j = j+1
#     print()
#     i = i+1




# n = int(input("Enter Limit: "))
# i = 1
# while(i<=n):
#     j = 1
#     while(j<=i):
#         print(i, end=" ")
#         j = j+1
#     print()
#     i = i+1



# n = int(input("Enter Limit: "))
# i = 1
# while(i<=n):
#     j = 1
#     while(j<=i):
#         print(j, end=" ")
#         j = j+1
#     print()
#     i = i+1


# with for loop


n = int(input("Enter Limit: "))
for i in range( n):
    for j in range(1, i):
        print(j, end=" ")
    print()
