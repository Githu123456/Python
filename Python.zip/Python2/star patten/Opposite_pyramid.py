n = int(input("Enter Limit: "))
i = 1

while(n>0):
    b = 1
    while(b<i):
        print(" ", end="")
        b = b+1
    j = 1
    while(j<=(n*2)-i):
        print("*", end="")
        j = j+1
    
    print()
    n = n-1
    i = i+1








# n = int(input("Enter Limit: "))
# i = 1
# k = 1
# while(i<=n):
#     b = 1
#     while(b<=n-i):
#         print(" ", end="")
#         b = b+1
#     j = 1
#     while(j<=k):
#         print("*", end="")
#         j = j+1
#     k = k+2
#     print()
#     i = i+1

# i = 1
# while(n>0):
#     b = 1
#     while(b<i):
#         print(" ", end="")
#         b = b+1
#     j = 1
#     while(j<=(n*2)-i):
#         print("*", end="")
#         j = j+1
    
#     print()
#     n = n-1
#     i = i+1