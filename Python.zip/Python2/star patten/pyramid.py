n = int(input("Enter Limit: "))
i = 1
k = 1
while(i<=n):
    b = 1
    while(b<=n-i):
        print(" ", end="")
        b = b+1
    j = 1
    while(j<=k):
        print("*", end="")
        j = j+1
    k = k+2
    print()
    i = i+1



# n = int(input("Enter Limit: "))
# i = 1
# k = 1
# while(i<=n):
#     b = 1
#     while(b<=n-i):
#         print(" ", end="")
#         b = b+1
#     j = 1
#     while(j<=k):
#         print(j, end="")
#         j = j+1
#     k = k+2
#     print()
#     i = i+1




# n = int(input("Enter Limit: "))
# i = 1
# k = 1
# while(i<=n):
#     b = 1
#     while(b<=n-i):
#         print(" ", end="")
#         b = b+1
#     j = 1
#     while(j<=k):
#         print(i, end="")
#         j = j+1
#     k = k+2
#     print()
#     i = i+1






# rows = int(input("Enter the number of rows for the pyramid: "))

# for i in range(rows):
#     # Print spaces in decreasing order
#     for j in range(rows - i - 1):
#         print(" ", end="")
    
#     # Print asterisks in increasing order
#     for k in range(2 * i + 1):
#         print(k, end="")
    
#     # Move to the next line
#     print()
