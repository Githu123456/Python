# write a programe to find of first n even numbers.

n = int(input("Enter max even number add: "))
i = 1
sum = 0
count = 0
while(count<n):
    if (i%2==0):
        sum = sum+i
    count = count+i
    i = i+1
print("Sum of even numbers: ", sum)