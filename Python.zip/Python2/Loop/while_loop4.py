# write a pograme to find sum of square from I to n.

n = int(input("Enter Number: "))
i = 1
sum = 0
while(i<=n):
    sum = sum + (i*i)
    i = i + 1
print("sum=", sum)