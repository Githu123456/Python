# write a programe to find sum of  even numbers between I to n.



# n =  int(input('Enter the max number: '))
# i = 2
# sum = 0
# while(i<=n):
#     sum = sum+i
#     i = i + 2

# print("sum of even number is : ", sum)


n =  int(input('Enter the max number: '))
i = 1
sum = 0
while(i<=n):
    if i%2==0:
        sum = sum+i
    i = i + 1
print("sum of even number is : ", sum)