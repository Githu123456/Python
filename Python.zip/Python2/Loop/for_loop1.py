# WRITE A PROGRAME TO PRINT TABLE TO GIVEN NUMBER.

n = int(input("Enter the Number to find table: "))

for i in range (1, 11):
    print(n*i)