# write a pograme to find product of digits of given number.

n = int(input("Enter the Number: "))
i = 1
while(n>0):
    i = i*(n%10)
    n = n//10
print("Product of digits: ", i)
