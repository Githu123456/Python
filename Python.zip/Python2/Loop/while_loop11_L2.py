# write a programe to find sum of cube of digits of a given number.
# when we enter the number 248 then the result will be like (2*2*2)+(4*4*4)+(8*8*8)= 584

n = int(input("Enter the number to find sum of degits: "))
sum = 0
while(n>0):
    sum = sum+(n%10)*(n%10)*(n%10)
    n = n//10
print("Sum of digits: ", sum)



#sum = sum+(n%10)*(n%10)*(n%10)
#    = 0+(248%10)*(248%10)*(248%10)  #248%10=24.8
#   =0+8*8*8 # %= moduler, so moduler allows take after point digit so it is thake only 8
#   =0+512

#n = n//10
# =248//10 # 248/10 = 24.8
# =24 # / = it will take point but // = it will not take point just take after point thats why i will 24
