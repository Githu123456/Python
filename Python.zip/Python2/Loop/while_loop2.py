n=int(input("Enter number: "))
i = 1
while(i<=n):
    print(i)
    i=i+1