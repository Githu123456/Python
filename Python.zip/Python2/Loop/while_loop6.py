# write a programe to print only even numbers between I to n.



# n =  int(input('Enter the max number: '))
# i = 2
# while(i<=n):
#     print(i)
#     i = i + 2


n =  int(input('Enter the max number: '))
i = 1
while(i<=n):
    if i%2==0:
        print(i)
    i = i + 1